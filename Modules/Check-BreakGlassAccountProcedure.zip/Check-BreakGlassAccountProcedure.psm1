<#
  Synopsis
   
#>

$PSDefaultParameterValues.Clear()
function Check-ProcedureDocument {
    param (
        [string] $StorageAccountName, [string] $ContainerName, [string] $ResourceGroupName, `
        [string] $ServicePrincipalName,  [string] $ServicePrincipalSecret, `
        [string] $TenantID , [string] $SubscriptionID, [string] $DocumentName, [string] $ControlName, [string]$ItemName, `
        [string] $WorkSpaceID, [string] $workspaceKey, [string] $LogType
        )

  [bool] $IsCompliant= $false
  [string] $Comments = $null
  $ServicePrincipalKey = ConvertTo-SecureString -String $ServicePrincipalSecret -AsPlainText -Force  

  $PsCredential = New-Object -TypeName System.Management.Automation.PSCredential($ServicePrincipalName,$ServicePrincipalKey)

 $null= Connect-AzAccount -ServicePrincipal -Credential $PsCredential  -Tenant $TenantID -SubscriptionID $SubscriptionID 

 $null= select-Azsubscription -SubscriptionID $SubscriptionID -TenantID $TenantID

  $StorageAccount= Get-Azstorageaccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName

  $StorageAccountContext = $StorageAccount.Context

  try {
    $Blobs= Get-AzStorageBlob -Container $ContainerName -Context $StorageAccountContext

    foreach ($Blob in $Blobs) {

        if($Blob.Name -eq $DocumentName){
              $IsCompliant = $True
        }
        else {
               $Comments = "Coudnt find index for +"   + $ItemName+ ", please create upload a file with a name " +$DocumentName+ " to confirm you have completed the Item in the control "
            }
    }
  }catch{}

  $PsObject = [PSCustomObject]@{
        ComplianceStatus= $IsCompliant
        ControlName = $ControlName
        ItemName = $ItemName
        DocumentName = $DocumentName
        Comments = $Comments
}
  $JsonObject= convertTo-Json -inputObject $PsObject 
            Send-OMSAPIIngestionFile -customerId $WorkSpaceID  -sharedkey $workspaceKey -body $JsonObject -logType $LogType -TimeStampField Get-Date 
}






                                

function Check-Policy  {
    Param (
        [string] $Token,
        [string] $AADPrivRolesPolicyName , 
        [string] $AzureMFAPolicyName ,
        [string] $FirstBreakGlassUPN,
        [string] $SecondBreakGlassUPN, 
        [string] $ControlName, 
        [string] $ItemName, 
        [string] $WorkSpaceID, 
        [string] $workspaceKey, 
        [string] $LogType)

    [bool] $IsCompliant= $false
    [string] $Comments= $null
    
   
    
    [PSCustomObject] $GRPolicies = New-Object System.Collections.ArrayList

    $PrivateRolePolicy= [PSCustomObject]@{
        PolicyName     = $AADPrivRolesPolicyName 
        PolicyID = $null
    }

    $MFAPolicy= [PSCustomObject]@{
        PolicyName     = $AADPrivRolesPolicyName 
        PolicyID = $null
    }

    $GRPolicies.add($PrivateRolePolicy)
    $GRPolicies.add($MFAPolicy)


    $apiUrl= "https://graph.microsoft.com/beta/identity/conditionalAccess/policies?$filter=displayName eq "+$PrivateRolePolicy

    $Data = Invoke-RestMethod -Headers @{Authorization = "Bearer $($token)"} -Uri $apiUrl -Method Get
    $policy = $Data.value
    $policyState= $policy.state

    $PolicyUsersAndGroupsExcluedUsers = $policy.conditions.users.excludeUsers

    $PolicyUsersAndGroupsIncludedRoles = $policy.conditions.users.includeRoles

    $PolicyCloudAppsIncludedApps = $policy.conditions.applications.includeApplications
     
    $PolicyGrantsMFA = $policy.grantControls.builtInControls
}  
function Check-conditionalAccess{
   
    param (
      [System.Array] $policy
    )



}
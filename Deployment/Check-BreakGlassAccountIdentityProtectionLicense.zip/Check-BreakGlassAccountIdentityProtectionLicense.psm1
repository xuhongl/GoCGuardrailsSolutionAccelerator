
function Get-BreakGlassAccountLicense {
    param (
       [string] $token, 
       [string] $FirstBreakGlassUPN,
       [string] $SecondBreakGlassUPN, 
       [string] $ControlName, 
       [string] $ItemName, 
       [string] $WorkSpaceID, 
       [string] $workspaceKey, 
       [string] $LogType
       )
    [bool] $IsCompliant= $false
    [string] $Comments= $null

    [PSCustomObject] $BGAccounts = New-Object System.Collections.ArrayList
     
    $FirstBreakGlassAcct= [PSCustomObject]@{
        UserPrincipalName     = $FirstBreakGlassUPN
        ID = $null
        LicenseDetails= "NOT ASSIGNED"
    }
    $SecondBreakGlassAcct= [PSCustomObject]@{
        UserPrincipalName     = $SecondBreakGlassUPN
        ID = $null
        LicenseDetails= "NOT ASSIGNED"
    }
        $BGAccounts.add( $FirstBreakGlassAcct)
        $BGAccounts.add( $SecondBreakGlassAcct)
        
    
   foreach ($BGAccount in $BGAccounts){
        
        $apiUrl=  $("https://graph.microsoft.com/beta/users/"+ $BGAccount.UserPrincipalName)
        $Data = Invoke-RestMethod -Headers @{Authorization = "Bearer $($token)"} -Uri $apiUrl -Method Get
        $BGAccount.ID =  $Data.id

        $apiUrl = $("https://graph.microsoft.com/beta/users/"+$BGAccount.ID+"/licenseDetails")
        $Data = Invoke-RestMethod -Headers @{Authorization = "Bearer $($token)"} -Uri $apiUrl -Method Get

        if(($data.value).Length -gt 0 ){
             $BGAccount.LicenseDetails= ($Data.value).skuPartNumber
    }
   }
        if($FirstBreakGlassAcct.LicenseDetails -eq "EMSPREMIUM"  -and  $SecondBreakGlassAcct.LicenseDetails -eq "EMSPREMIUM" ){

            $IsCompliant= $true
            $Comments= $FirstBreakGlassAcct.UserPrincipalName +" Assigned License = "+  $FirstBreakGlassAcct.LicenseDetails +
                       $SecondBreakGlassAcct.UserPrincipalName +" Assigned License = "+  $SecondBreakGlassAcct.LicenseDetails 
   }    else {
             $Comments= $FirstBreakGlassAcct.UserPrincipalName +" Assigned License = "+  $FirstBreakGlassAcct.LicenseDetails +" & "+
             $SecondBreakGlassAcct.UserPrincipalName +" Assigned License = "+  $SecondBreakGlassAcct.LicenseDetails 
   }

   $PsObject = [PSCustomObject]@{
    ComplianceStatus= $IsCompliant
    ControlName = $ControlName
    Comments= $Comments
    ItemName= $ItemName
 }
 $JsonObject = convertTo-Json -inputObject $PsObject 

 Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
                           -sharedkey $workspaceKey `
                           -body $JsonObject `
                           -logType $LogType `
                           -TimeStampField Get-Date 
   
}
#$PSDefaultParameterValues.Clear()

function Get-ADLicenseType {
    
 param (
     [string] $token, 
     [string] $ControlName,
     [string] $WorkSpaceID, 
     [string] $workspaceKey, 
     [string] $LogType,
     [string] $ItemName
)
    $ADLicenseType  = "N/A"
    $IsCompliant = $false
    $apiUrl = "https://graph.microsoft.com/v1.0/subscribedSkus"
    $Data = Invoke-RestMethod -Headers @{Authorization = "Bearer $($token)"} -Uri $apiUrl -Method Get
    $subscribedSkus = $Data.Value
    $servicePlans=  $subscribedSkus.servicePlans

    foreach ($servicePlan in $servicePlans) {
        if($servicePlan.servicePlanName -eq "AAD_PREMIUM_P2"){
            $IsCompliant = $true
            $ADLicenseType  = $servicePlan.servicePlanName
        }
    }

    $PsObject = [PSCustomObject]@{
        ComplianceStatus= $IsCompliant
        ControlName = $ControlName
        ADLicenseType = $ADLicenseType
        ItemName= $ItemName
     }
     $JsonObject = convertTo-Json -inputObject $PsObject 

     Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
                               -sharedkey $workspaceKey `
                               -body $JsonObject `
                               -logType $LogType `
                               -TimeStampField Get-Date 

}

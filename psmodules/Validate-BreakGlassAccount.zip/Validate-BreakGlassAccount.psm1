function Get-BreakGlassAccounts {
   
  param (
    [string] $FirstBreakGlassUPN, 
    [string] $SecondBreakGlassUPN,
    [string] $token, 
    [string] $LogType,
    [string] $WorkSpaceID,
    [string] $WorkspaceKey, 
    [string] $ControlName, 
    [string] $ItemName
  )
  [bool] $FirstBGAcctExist = $false
  [bool] $SecondBGAcctExist = $false
   
    
  [bool] $IsCompliant = $false

  #  [PSCustomObject] $BGAccounts = New-Object System.Collections.ArrayList

  [String] $FirstBreakGlassUPNUrl = $("https://graph.microsoft.com/beta/users/" + $FirstBreakGlassUPN)
  [String] $SecondBreakGlassUPNUrl = $("https://graph.microsoft.com/beta/users/" + $SecondBreakGlassUPN)
  <#)#>

  $FirstBreakGlassAcct = [PSCustomObject]@{
    UserPrincipalName  = $FirstBreakGlassUPN
    apiUrl             = $FirstBreakGlassUPNUrl
    First_Name         = $null
    Last_Name          = $null
    Mobile_PhoneNumber = $null
    Email_address      = $null
    ComplianceStatus   = $false
  }
  $SecondBreakGlassAcct = [PSCustomObject]@{
    UserPrincipalName  = $SecondBreakGlassUPN
    apiUrl             = $SecondBreakGlassUPNUrl
    First_Name         = $null
    Last_Name          = $null
    Mobile_PhoneNumber = $null
    Email_address      = $null
    ComplianceStatus   = $false
  }
    
  try {
    $Data = Invoke-RestMethod -Headers @{Authorization = "Bearer $($token)" } -Uri $FirstBreakGlassAcct.apiUrl -Method Get
   
    if ($Data.userType -eq "Member") {
      $FirstBGAcctExist = $true
    } 
    $Data = Invoke-RestMethod -Headers @{Authorization = "Bearer $($token)" } -Uri $SecondBreakGlassAcct.apiUrl -Method Get
    
    if ($Data.userType -eq "Member") {
      $SecondBGAcctExist = $true
    } 
  }
  catch {
    $Statuscode = $_.exception.message

  }
  $IsCompliant = $FirstBGAcctExist -and $SecondBGAcctExist

  $PsObject = [PSCustomObject]@{
    ComplianceStatus = $IsCompliant
    ControlName      = $ControlName
    ItemName         = $ItemName
    Comment          = $FirstBreakGlassUPN + " Compliance status = " + $FirstBGAcctExist + " " + "," + " " + $SecondBreakGlassUPN + " Compliance status  =" + $SecondBGAcctExist
  }

  $JsonObject = convertTo-Json -inputObject $PsObject 

  Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
    -sharedkey $workspaceKey `
    -body $JsonObject `
    -logType $LogType `
    -TimeStampField Get-Date 
}    

function Check-CBSSensors {
    param (
        [string] $SubscriptionName , [string] $TenantID , [string] $ControlName, `
        [string] $WorkSpaceID, [string] $workspaceKey, [string] $LogType
    )

    $IsCompliance = $true 
    [string] $Comment1 = "CBS Subscription doesnt exist"
    [string] $Comment2 = "The excpected CBC sensors do not exist"
    $Object = New-Object PSObject

    $Object | Add-Member -MemberType NoteProperty -Name ControleName  -Value $ControlName
    $object | Add-Member -MemberType NoteProperty -Name CompliantStatus -Value $IsCompliance


    $FirstTokenInTenantID = $TenantID.Split("-")[0]

    [string]$CBSFunctionName = "cbs-" + $FirstTokenInTenantID 
    [string]$CBSCCEventHubsNameSpace = "cbs-" + $FirstTokenInTenantID + "-CanadaCentral"
    [string]$CBSCEEventHubsNameSpace = "cbs-" + $FirstTokenInTenantID + "-CanadaEast"
    [string]$CBSKeyVaultName = "cbs-vault-" + $FirstTokenInTenantID
    [string]$CBSStorageAccountName = $FirstTokenInTenantID
    [string]$CBSAppServicePlanName = "CbsSitePlan"

    Set-AzContext -Subscription $SubscriptionName -Tenant $TenantID

    $CBSFunctionNameRS = Get-AzResource -Name $CBSFunctionName
    $CBSCCEventHubsNameSpaceRS = Get-AzResource -Name $CBSCCEventHubsNameSpace
    $CBSCEEventHubsNameSpaceRS = Get-AzResource -Name $CBSCEEventHubsNameSpace
    $CBSKeyVaultNameRS = Get-AzResource  -Name $CBSKeyVaultName
    $CBSStorageAccountNameRS = Get-AzResource  -Name $CBSStorageAccountName
    $CBSAppServicePlanNameRS = Get-Azresource - name $CBSAppServicePlanName

    if ((-$null -eq $SubscriptionName ) -or ([string]::IsNullOrEmpty($SubscriptionName))) {
        $IsCompliance = $false
        $Object | Add-Member -MemberType NoteProperty -Name Comments -Value $Comment1
    } 
    elseif ((-$null -eq $CBSFunctionNameRS) -or (-$null -eq $CBSCCEventHubsNameSpaceRS) -or `
        (-$null -eq $CBSCEEventHubsNameSpaceRS) -or (-$null -eq $CBSKeyVaultNameRS) -or `
        (-$null -eq $CBSStorageAccountNameRS) -or (-$null -eq $CBSAppServicePlanNameRS)) {
        $IsCompliance = $false 
        $Object | Add-Member -MemberType NoteProperty -Name Comments -Value $Comment2
    }
    $JsonObject = convertTo-Json -inputObject $Object 

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JsonObject `
        -logType $LogType `
        -TimeStampField Get-Date          
}

